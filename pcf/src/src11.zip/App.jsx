import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Home from "./Pages/Home";
import About from "./Pages/About";
import Accommodation from "./Pages/Accommodation"
import Gallery from "./Pages/Gallery";
import Footer from "./components/Footer";
import "./App.css"; // Ensure global styles are applied
import Thing from "./Pages/Thing";
import Location from "./Pages/Location";


function App() {
  return (
    <Router>
      <div className="app">
        <Navbar />
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/thing" element={<Thing/>} />
          <Route path="/accommodation" element={<Accommodation/>} />
          <Route path="/gallery" element={<Gallery/>} />
          <Route path="/location" element={<Location/>} />
        </Routes>
        <Footer/>
      </div>
    </Router>
  );
}

export default App;
