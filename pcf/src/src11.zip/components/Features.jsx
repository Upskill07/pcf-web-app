import React from "react";
import "./Features.css"; // Import styles if needed

import i11 from "../assets/img/i11.jpg";
import i15 from "../assets/img/i15.jpg";
import i16 from "../assets/img/i16.jpg";
import i4 from "../assets/img/i4.jpg";
import i7 from "../assets/img/i7.jpg";
import i5 from "../assets/img/i5.jpg";

function Features() {
    const featuresData = [
      {
        imgSrc: i11,
        title: "Easy Treks Around",
        description:
          "Surrounded by rolling hills, Marigold offers easy treks suitable for all levels. Explore scenic trails, enjoy breathtaking views, and reconnect with nature.",
      },
      {
        imgSrc: i15,
        title: "Pick and Cook",
        description:
          "We grow a variety of organic vegetables like garlic, onions, radish, etc. Enjoy picking fresh produce and cooking it on-site for a farm-to-table experience.",
      },
      {
        imgSrc: i16,
        title: "Outdoor Classic Hut (Workspace)",
        description:
          "Our Outdoor Hut is a productive workspace, a cozy hangout spot, or a place to celebrate. Surrounded by nature, it’s perfect for connection.",
      },
      {
        imgSrc: i4,
        title: "Kids Friendly",
        description:
          "Children explore nature through hands-on activities like picking produce and watering plants. A great educational experience for kids.",
      },
      {
        imgSrc: i7,
        title: "Cozy Bonfire Gatherings",
        description:
          "As the sun sets, gather around the bonfire for warmth and conversation. Share stories under the starlit sky and enjoy the crackling fire.",
      },
      {
        imgSrc: i5,
        title: "Night View",
        description:
          "Wake up to stunning panoramic views of Sinhagad Fort, where the hills meet Marigold’s serene landscape. A peaceful backdrop for exploration.",
      },
    ];
  
    return (
      <section className="features">
        <div className="container">
          <h1 id="features" style={{ color: "#5e2d07", textAlign: "center", marginBottom: "20px" }}>
            Our Facilities
          </h1>
          <div className="row row-cols-1 row-cols-md-3 g-4">
            {featuresData.map((feature, index) => (
              <div key={index} className="col">
                <div className="card h-100 shadow-lg">
                  <img src={feature.imgSrc} className="card-img-top" alt={feature.title} />
                  <div className="card-body">
                    <h5 className="card-title" style={{ color: "#5e2d07" }}>
                      {feature.title}
                    </h5>
                    <p className="card-text">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }export default Features;
