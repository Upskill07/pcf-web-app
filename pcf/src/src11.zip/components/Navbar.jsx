import { useState } from "react";
import { Menu, X } from "lucide-react";
import "../components/Navbar.css";
import { NavLink } from 'react-router-dom';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
    <nav className="navbar">
      <div className="wrapper">
        {/* Logo */}
        <div className="logo">
          <a href="/">
            <h1 className="logo"> Marigold <span className="small-text">Live.Love.Laugh</span></h1>
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button className="menu-btn" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={30} /> : <Menu size={30} />}
        </button>

        {/* Navigation Links */}
        <ul className={`nav-links ${isOpen ? "open" : ""}`}>
          <li><NavLink exact to="/" activeClassName="active" onClick={() => setIsOpen(false)}>Home</NavLink></li>
          <li><NavLink to="/about" activeClassName="active" onClick={() => setIsOpen(false)}>About</NavLink></li>
          <li><NavLink to="/accommodation" activeClassName="active" onClick={() => setIsOpen(false)}>Accommodation</NavLink></li>
          <li><NavLink to="/thing" activeClassName="active" onClick={() => setIsOpen(false)}>Things To Do</NavLink></li>
          <li><NavLink to="/gallery" activeClassName="active" onClick={() => setIsOpen(false)}>Gallery</NavLink></li>
          <li><NavLink to="/location" activeClassName="active" onClick={() => setIsOpen(false)}>Location</NavLink></li>
        </ul>
      </div>
    </nav>
    </>
  );
}
