
import '../components/Footer.css'

const Footer = () => {
  return (
    <>

    <div className="footer-bottom">
      <p>Copyright © 2024-2025 Marigold DB's Organic Retreat All Rights Reserved.</p>
    </div>
    </>
  )
}

export default Footer