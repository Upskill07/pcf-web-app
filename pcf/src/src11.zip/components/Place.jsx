import React from "react";
import "./Place.css";

import pabg from "../assets/img/pabg.jpg";
import k from "../assets/img/k.jpeg";
import sf from "../assets/img/sf.jpeg";
import pd from "../assets/img/pd.jpeg";
import tf from "../assets/img/tf.jpeg";
import rf from "../assets/img/rf.jpeg";

const placeData = [
  {
    imgSrc: pabg,
    altText: "Pabe Ghat Hill View Point",
    title: "Pabe Ghat Hill View Point (8 km from Marigold)",
    description:
      "Experience breathtaking panoramic views of the surrounding hills and valleys at Pabe Ghat Hill View Point, just a short drive from Marigold. A must-visit for nature lovers and photography enthusiasts.",
    delay: 0,
  },
  {
    imgSrc: k,
    altText: "Krushnai Water Park",
    title: "Krushnai Water Park (10 km)",
    description:
      "Perfect for a fun-filled day with family and friends, Krushnai Water Park offers a variety of thrilling water slides and relaxing pools, making it an ideal spot to cool off during the warmer months.",
    delay: 100,
  },
  {
    imgSrc: sf,
    altText: "Sinhagad Fort",
    title: "Sinhagad Fort (12 km)",
    description:
      "Step back in time with a visit to Sinhagad Fort, a historic stronghold offering scenic treks and incredible views. Rich in history and surrounded by nature, it’s an unforgettable experience.",
    delay: 200,
  },
  {
    imgSrc: pd,
    altText: "Panshet Dam",
    title: "Panshet Dam & Varasgaon Dam (20 km)",
    description:
      "Enjoy a peaceful day by the water at Panshet and Varasgaon Dams. Ideal for picnics, boating, or just relaxing by the calm waters, these dams offer a serene escape into nature.",
    delay: 300,
  },
  {
    imgSrc: tf,
    altText: "Torana Fort",
    title: "Torana Fort (26 km)",
    description:
      "Explore the majestic Torana Fort, perched high on a hill. Known for its historical significance and panoramic views, it’s a rewarding trek for those who enjoy a good adventure.",
    delay: 400,
  },
  {
    imgSrc: rf,
    altText: "Rajgad Fort",
    title: "Rajgad Fort (28 km)",
    description:
      "One of the most iconic forts in Maharashtra, Rajgad Fort offers rich history and sweeping views of the Sahyadri range. It's a great spot for trekking and a journey through time.",
    delay: 500,
  },
];

const PlaceCard = ({ imgSrc, altText, title, description, delay }) => (
  <div className="place-card" data-aos="fade-up" data-aos-delay={delay}>
    <img src={imgSrc} alt={altText} className="place-img" />
    <div className="place-body">
      <h5 className="place-title">{title}</h5>
      <p className="place-text">{description}</p>
    </div>
  </div>
);

const Place = () => (
  <div className="container">
    <h2 className="section-title">Popular Places from Marigold</h2>
    <div className="place-grid">
      {placeData.map((place, index) => (
        <PlaceCard key={index} {...place} />
      ))}
    </div>
  </div>
);

export default Place;
