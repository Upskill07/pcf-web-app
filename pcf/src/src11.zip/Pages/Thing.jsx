import React from 'react'
import Features from '../components/Features'
import Place from  '../components/Place'



const Thing = () => {
  return (
    <div>
      
      <Features/>
      <Place/>
      {/*Call Widget and Whatsapp widget */}
   <div>
      <div className="elfsight-app-f3c97c47-3982-481f-9977-266e86aa2921" data-elfsight-app-lazy></div>
      <div className="elfsight-app-d2a9b47f-73c5-44a9-b8da-af5b91e0a919" data-elfsight-app-lazy></div>
    </div>

 {/*------------ */}  
    </div>
  )
}

export default Thing