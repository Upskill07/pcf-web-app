import React from 'react';
import './Accommodation.css';
import tent from "../assets/img/tent.mp4";
import cottage from "../assets/img/cotagev.mp4";

const Accommodation = () => {
  return (

    
    <div className="container-acc">
      <div className="heading-acc">Accommodation</div>
      <p className="acco-p">
        At Marigold, we believe in providing a peaceful, comfortable, and
        nature-immersed stay, allowing you to disconnect from the hustle and
        bustle of daily life while reconnecting with nature. Our accommodations
        are designed to offer a perfect blend of comfort and eco-friendly
        living, ensuring a memorable experience for you and your loved ones.
        <b>
          {" "}
          What makes your stay even more special is that our accommodations
          offer complete privacy, with no shared spaces with other guests—
          ensuring an exclusive and allowing you to enjoy the retreat to its
          fullest.
        </b>
      </p>
      <h4 style={{ color: "#5e2d07" }} className="acc-h4">Perfect for:</h4>
      <p className="acco-p">
        Small families, groups up to 7 people, long staycation, remote workers,
        couples or solo travelers seeking tranquility.
      </p>
      <br />
      <h3 className="acc-h3">Our Packages</h3>
      <div className="row row-cols-1 row-cols-md-3 g-4">
        <div className="col" id="pack">
          <div className="card" id="bg">
            <div className="card-body" style={{ backgroundColor: "#f4f4f4" }}>
              <h5 className="card-title" id="op">Upto 2-3 People</h5>
              <p className="card-text" id="rs">Check-In-1pm onwards <br /> Check-Out:10.30am</p>
            </div>
          </div>
        </div>
        <div className="col" id="pack">
          <div className="card" id="bg">
            <div className="card-body" style={{ backgroundColor: "#f4f4f4" }}>
              <h5 className="card-title" id="op">Upto 4-5 People</h5>
              <p className="card-text" id="rs">Check-In-1pm onwards <br /> Check-Out:10.30am</p>
            </div>
          </div>
        </div>
        <div className="col" id="pack">
          <div className="card" id="bg">
            <div className="card-body" style={{ backgroundColor: "#f4f4f4" }}>
              <h5 className="card-title" id="op">Upto 5-7 People</h5>
              <p className="card-text" id="rs">Check-In-1pm onwards <br /> Check-Out:10.30am</p>
            </div>
          </div>
        </div>
      </div>
      <br />
      <div className="content-acc">
        <div className="slider-container">
          <video autoPlay muted loop width="450" style={{ border: "1px solid black" }}>
            <source src={cottage} type="video/mp4" />
          </video>
        </div>
        <div className="text-acc">
          <h3 className="acc-h3">Marigold Cottage</h3>
          <h5 className="acc-h5">(Exclusive Private Stay)</h5>
          <p className="acco-p">
            Marigold is a cozy cottage nestled amidst lush greenery with a
            rustic theme to blend seamlessly with the natural surroundings.<b>
              {" "}
              With only one cottage on the property, you will enjoy complete
              seclusion, surrounded by the beauty of the organic farm and
              panoramic hill views.</b> Designed with comfort and tranquility in
            mind, the cottage is equipped with comfortable amenities and
            warmth, making it an authentic countryside experience, ideal for
            relaxation or work.
          </p>
          <p className="acco-p">
            The cottage features earthy, natural materials that offer comfort,
            warmth, and an authentic countryside experience.
          </p>
        </div>
      </div>
      <div className="content-acc">
        <div className="text-acc">
          <h3 className="acc-h3">Tent Camping Experience</h3>
          <h5 className="acc-h5">(Perfect for Groups/Kids)</h5>
          <p className="acco-p">
            Our cozy 2-person tents offer a unique glamping experience, ideal
            for large groups or to extend the camping experience with kids.
            Tents provide the perfect mix of outdoor adventure and comfort.
            Each tent features comfortable bedding and lighting. It's a
            wonderful way for families to bond and for kids to explore nature
            in a safe, private setting.
          </p>
        </div>
        <div className="slider-container">
          <video autoPlay muted loop width="450" style={{ border: "1px solid black" }}>
            <source src={tent} type="video/mp4" />
          </video>
        </div>
      </div>

      {/*Call Widget and Whatsapp widget */}
   <div>
      <div className="elfsight-app-f3c97c47-3982-481f-9977-266e86aa2921" data-elfsight-app-lazy></div>
      <div className="elfsight-app-d2a9b47f-73c5-44a9-b8da-af5b91e0a919" data-elfsight-app-lazy></div>
    </div>
    {/*------------ */}  
    </div>
  );
};

export default Accommodation;
