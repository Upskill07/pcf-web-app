import React from 'react'
import '../Pages/location.css'



const Location = () => {
  return (
    
<>
<div className="map-and-info">
      <div className="map-container">
        
        <iframe
          title="map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3786.3099661042!2d73.70633987423382!3d18.378738673493228!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc29144087bf515%3A0xd3ac6967bced733e!2sMarigold%20-%20DB&#39;s%20Organic%20Retreat!5e0!3m2!1sen!2sin!4v1737734699680!5m2!1sen!2sin"
          width="600"
          height="450"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
        ></iframe>
      </div>
      <div className="info-text">
      <h2 className='map-h2'>MAP</h2>
        <h2>Where exactly are we located?</h2>
        <p>
          Marigold Retreat is located just 15 km from Khadakwasala Dam, Pune. It is just around a 1-hour drive from major places in the city like Baner, Swargate, Katraj, Warje, Kothrud, Hadapsar etc.
        </p>
      </div>
    </div>
    {/*Call Widget and Whatsapp widget */}
   <div>
      <div className="elfsight-app-f3c97c47-3982-481f-9977-266e86aa2921" data-elfsight-app-lazy></div>
      <div className="elfsight-app-d2a9b47f-73c5-44a9-b8da-af5b91e0a919" data-elfsight-app-lazy></div>
    </div>

 {/*------------ */}  
</>
  )
}

export default Location