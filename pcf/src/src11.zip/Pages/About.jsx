import React from 'react'
import '../Pages/About.css'
import i1 from "../assets/img/i1.jpg"


const About = () => {
  return (
    <div>
         <div className="container-about">
      <div className="text-content-ab">
        <h1 className='head-ab'>Marigold-DB's Organic Retreat</h1>
        <p className="content-ab">
          Marigold - DB's Organic Retreat, Pune, developed by nature enthusiast Dnyaneshwar Birajdar (DB) and established in January 2024, offers a unique experiential living campsite focused on organic farming, outdoor cooking, and reconnecting with nature. Our philosophy is simple: <b>Live. Love. Laugh</b> —embracing life fully, fostering deep connections, and finding joy in every moment.
        </p>
        <p className="content-ab">
          Located in a serene, hilly area, this retreat offers guests the opportunity to escape the hustle and bustle of city life and immerse themselves in the beauty of the countryside.<br /><br />
          At Marigold, we invite families and children to reconnect with the environment through hands-on experiences. Guests can explore organic farming, learn about a variety of vegetables grown on-site, and engage in the rewarding activity of "Pick & Cook." Prepare meals using fresh, homegrown produce on a traditional chulla (wood-fired stove) or a gas cylinder, all while embracing the simplicity of outdoor cooking under the open sky. Our retreat offers a peaceful, nature-driven experience, perfect for those looking to unwind, bond with loved ones, and live sustainably in harmony with the earth.
        </p>
      </div>
      <div className="image-container-ab">
        <img src={i1} alt="Cottage at Marigold Retreat" />
        <div className="review-box-ab">
          <p>Visitors say this cottage offers a peaceful getaway surrounded by nature with amenities like a cozy fireplace, outdoor seating hut perfect for relaxing. They also highlight breathtaking views, a tranquil atmosphere, and the welcoming and communicative host.</p>
          <div className="stars-ab">★★★★★</div>
        </div>
      </div>
    </div>
      {/*Call Widget and Whatsapp widget */}
   <div>
      <div className="elfsight-app-f3c97c47-3982-481f-9977-266e86aa2921" data-elfsight-app-lazy></div>
      <div className="elfsight-app-d2a9b47f-73c5-44a9-b8da-af5b91e0a919" data-elfsight-app-lazy></div>
    </div>

 {/*------------ */}  
    </div>
  )
}

export default About