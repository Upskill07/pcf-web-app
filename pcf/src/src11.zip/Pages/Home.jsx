import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import i1 from "../assets/img/i1.jpg";
import i16 from "../assets/img/i16.jpg";
import p3 from "../assets/img/p3.jpg";
import i4 from "../assets/img/i4.jpg";
import i11 from "../assets/img/i11.jpg";
import cotage from "../assets/img/cotage.jpg";
import Features from '../components/Features'
import '../Pages/Home.css'
import { FaReact, FaInstagram, FaFacebook, FaYoutube } from 'react-icons/fa';





const Home = () => {
  return (
    
    <div>

<div className="container-fluid p-0">
  <div id="header-carousel" className="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
    <div className="carousel-inner">
      <div className="carousel-item active">
        <img className="w-100" src={i1} alt="Image" />
      </div>
      <div className="carousel-item">
        <img className="w-100" src={i16} alt="Image" />
      </div>
      <div className="carousel-item">
        <img className="w-100" src={p3} alt="Image" />
      </div>
      <div className="carousel-item">
        <img className="w-100" src={cotage} alt="Image" />
      </div>
    </div>
    <button className="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
      <span className="carousel-control-prev-icon"></span>
    </button>
    <button className="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
      <span className="carousel-control-next-icon"></span>
    </button>
  </div>
</div>





      <br></br>
      <div>
     
      <script src="https://static.elfsight.com/platform/platform.js" async></script>
      <div class="elfsight-app-bfc7c7ac-bec7-4457-9d66-f14c1009c79e" data-elfsight-app-lazy></div>
    </div>

    {/*Features */}
      <Features/>

{/*Gallery */}

<div className="container mt-4">
  {/* Centered Gallery Title */}
  <h1 style={{ color: "#5e2d07", textAlign: "center" }} id="txtb">
    Gallery
  </h1>

  {/* Centered row with gap */}
  <div className="row g-3">
    {/* Image Card 1 */}
    <div className="col-12 col-md-6 col-lg-5 d-flex ">
      <div 
        className="card shadow-sm border-0 rounded-3  gcard" 
        
      >
        <img 
          src={i4} 
          className="card-img-top img-fluid" 
          alt="Gallery Image 1" 
          style={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: "8px" }} 
        />
      </div>
    </div>

    {/* Image Card 2 */}
    <div className="col-12 col-md-6 col-lg-5 d-flex justify-content-center">
      <div 
        className="card shadow-sm border-0 rounded-3 overflow-hidden gcard" 
       
      >
        <img 
          src={i11} 
          className="card-img-top img-fluid" 
          alt="Gallery Image 2" 
          style={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: "8px" }} 
        />
      </div>
    </div>
  </div>

  <br />

  {/* Centered "View More" button */}
  <div className="text-center">
  <a className="view-btn" href="Gallery">
   
      View More
    
  </a>
</div>
</div>

{/*Call Widget and Whatsapp widget */}
   <div>
      <div className="elfsight-app-f3c97c47-3982-481f-9977-266e86aa2921" data-elfsight-app-lazy></div>
      <div className="elfsight-app-d2a9b47f-73c5-44a9-b8da-af5b91e0a919" data-elfsight-app-lazy></div>
    </div>

 {/*------------ */}   

{/*Footer */}
<br></br>
<footer className="footer">
    <div className="footer-container">
        <div className="footer-column company-column">
            <h4>Marigold - DB's Organic Retreat</h4>
            <p>
                Marigold - DB's Organic Retreat, Pune, developed by nature enthusiast Dnyaneshwar Birajdar (DB) and established in January 2024, offers a unique experiential living campsite focused on organic farming, outdoor cooking, and reconnecting with nature and loved ones. Our philosophy is simple: Live, Love, Laugh—embracing life fully, fostering deep connections, and finding joy in every moment.
            </p>
        </div>
        
        <div className="footer-column">
            
            <div className="logo1">
                <h4>Follow Us</h4>

                <p ><i className="fas fa-home mr-3"></i> Wardade, Pune Maharashtra 412212</p>
                <ul id="ficon" >
                    <a href="https://www.instagram.com/db.marigold?igsh=MWV0djRyNnljZ2xzZg==" target="_blank" rel="noopener noreferrer" title="Instagram">
                        <FaInstagram size={30} color="#E1306C" />
                    </a>
                    <a href="https://www.facebook.com/share/19wuTRpnkS/" target="_blank" rel="noopener noreferrer" title="Facebook">
                        <FaFacebook size={30} color="#1877F2" />
                    </a>
                    <a href="https://youtube.com/@marigold-dbsorganicretreat?si=v3W6o6etVzntpGa5" target="_blank" rel="noopener noreferrer" title="YouTube">
                        <FaYoutube size={30} color="#FF0000" />
                    </a>
                </ul>
                

                <iframe  height="80px" width="300px" frameBorder="0" src="https://livecounts.io/embed/youtube-live-subscriber-counter/UCEc30FsAcbtP6-3C6-trZHw" style={{border: 0}}></iframe>
               
            
              
                
                </div>
        </div>
    </div>
</footer>

    
    </div>
  );
};


export default Home