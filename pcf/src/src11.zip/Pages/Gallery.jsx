import { useState } from "react";
import "./Gallery.css"; 

import cotage from "../assets/img/cotage.jpg";
import p3 from "../assets/img/p3.jpg";
import i1 from "../assets/img/i1.jpg";
import c2 from "../assets/img/c2.jpg";
import i3 from "../assets/img/i3.jpg";
import i5 from "../assets/img/i5.jpg";
import i16 from "../assets/img/i16.jpg";
import p1 from "../assets/img/p1.jpg";
import i7 from "../assets/img/i7.jpg";
import i2 from "../assets/img/i2.jpg";
import i12 from "../assets/img/i12.jpg";
import i4 from "../assets/img/i4.jpg";
import hut from "../assets/img/hut.jpg";
import p2 from "../assets/img/p2.jpg";
import i8 from "../assets/img/i8.jpg";
import p5 from "../assets/img/p5.jpg";
import fram from "../assets/img/fram.jpg";
import b3 from "../assets/img/b3.jpg";
import f1 from "../assets/img/f1.jpg";
import f2 from "../assets/img/f2.jpg";
import l3 from "../assets/img/l3.jpeg";
import l4 from "../assets/img/l4.jpeg";
import kitchen from "../assets/img/kitchen.jpg";
import tentVideo from "../assets/img/tent.mp4";
import f1Video from "../assets/img/f1.mp4";
import f2Video from "../assets/img/f2.mp4";
import f3Video from "../assets/img/f3.mp4";
import f4Video from "../assets/img/f4.mp4";

const categories = ["All", "Day View", "Night View", "Hut", "Farming", "Nature", "Kitchen", "Video"];

const images = [
  { src: cotage, category: "Day View", caption: "Sunny Landscape 1" },
  { src: p3, category: "Day View", caption: "Sunny Landscape 2" },
  { src: i1, category: "Day View", caption: "Sunny Landscape 3" },
  { src: c2, category: "Day View", caption: "Sunny Landscape 4" },
  { src: i3, category: "Day View", caption: "Sunny Landscape 5" },
  { src: i5, category: "Night View", caption: "Starry Night 1" },
  { src: i16, category: "Night View", caption: "Starry Night 2" },
  { src: p1, category: "Night View", caption: "Starry Night 3" },
  { src: i7, category: "Night View", caption: "Starry Night 4" },
  { src: i2, category: "Hut", caption: "Cozy Hut Stay Experience" },
  { src: i12, category: "Hut", caption: "Cozy Hut Stay Experience" },
  { src: i4, category: "Hut", caption: "Cozy Hut Stay Experience" },
  { src: hut, category: "Hut", caption: "Cozy Hut Stay Experience" },
  { src: p2, category: "Farming", caption: "Nature & Farming" },
  { src: i8, category: "Farming", caption: "Nature & Farming" },
  { src: p5, category: "Farming", caption: "Nature & Farming" },
  { src: fram, category: "Farming", caption: "Nature & Farming" },
  { src: b3, category: "Nature", caption: "Peaceful Greenery" },
  { src: f1, category: "Nature", caption: "Peaceful Greenery" },
  { src: i1, category: "Nature", caption: "Peaceful Greenery" },
  { src: f2, category: "Nature", caption: "Peaceful Greenery" },
  { src: l3, category: "Nature", caption: "Peaceful Greenery" },
  { src: l4, category: "Nature", caption: "Peaceful Greenery" },
  { src: kitchen, category: "Kitchen", caption: "Kitchen View" },
  { src: tentVideo, category: "Video", caption: "Tent video", type: "video" },
  { src: f1Video, category: "Video", caption: "Farming video", type: "video" },
  { src: f2Video, category: "Video", caption: "Farm and Nature", type: "video" },
  { src: f3Video, category: "Video", caption: "Farm Life", type: "video" },
  { src: f4Video, category: "Video", caption: "Greenery", type: "video" },
];

export default function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedImage, setSelectedImage] = useState(null);

  const filteredImages = selectedCategory === "All"
    ? images
    : images.filter((img) => img.category === selectedCategory);

  return (
    <div className="gallery-container">
      <h1 className="gallery-title">Gallery</h1>
      
      {/* Category Buttons */}
      <div className="category-buttons">
        {categories.map((category) => (
          <button
            key={category}
            className={`category-button ${selectedCategory === category ? "active" : ""}`}
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Image Grid */}
      <div className="image-grid">
        {filteredImages.map((item, index) => (
          item.type === "video" ? (
            <video
              key={index}
              src={item.src}
              className="gallery-video"
              controls
              onClick={() => setSelectedImage(item)}
            />
          ) : (
            <img
              key={index}
              src={item.src}
              alt={item.caption}
              className="gallery-image"
              onClick={() => setSelectedImage(item)}
            />
          )
        ))}
      </div>

      {/* Simple Enlarged View */}
      {selectedImage && (
        <div className="lightbox" onClick={() => setSelectedImage(null)}>
          <div className="lightbox-content">
            <span className="close-button" onClick={() => setSelectedImage(null)}>&times;</span>
            {selectedImage.type === "video" ? (
              <video src={selectedImage.src} className="enlarged-video" controls />
            ) : (
              <img src={selectedImage.src} alt={selectedImage.caption} className="enlarged-image" />
            )}
          </div>
        </div>
      )}
    </div>
  );
}
